#ifndef SID_H
#define SID_H

int get_sid(char* sidname);

#endif /* SID_H */
