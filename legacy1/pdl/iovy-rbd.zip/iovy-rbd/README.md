# iovyroot
A root tool based on the [CVE-2015-1805 vulnerability](https://access.redhat.com/security/cve/cve-2015-1805)

It supports 32 and 64bit but requires absolute kernel addresses (see [offsets.c](jni/offsets.c))



poc was done by idler1984 https://github.com/idl3r/testcode